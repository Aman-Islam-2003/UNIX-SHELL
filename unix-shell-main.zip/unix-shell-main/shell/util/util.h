/**
 * @file util.h
 * @author Aymen Bennabi | Hajer Gafsi
 * @brief  Holds the blueprint of utility functions
 * @version 0.1
 * @date 2021-11-30
 * 
 * @copyright Copyright (c) 2021
 * 
 */
#ifndef UTIL_H
#define UTIL_H


void displayError(char*,char*);
int getNumberOfWords(char*);
#endif
